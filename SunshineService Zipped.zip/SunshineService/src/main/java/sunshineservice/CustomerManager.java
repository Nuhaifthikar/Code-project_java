
package sunshineservice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class CustomerManager {
    private static final String FILE_NAME = "customers.dat";
    private final List<Customer> customers;

    public CustomerManager() {
        customers = loadCustomers();
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
        saveCustomers();
    }

    public void updateCustomer(String customerID, String name, String contact, String email) {
        for (Customer c : customers) {
            if (c.getCustomerID().equals(customerID)) {
                c.setName(name);
                c.setContactNumber(contact);
                c.setEmail(email);
                saveCustomers();
                break;
            }
        }
    }

    private void saveCustomers() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(customers);
        } catch (IOException e) {
        }
    }

    private List<Customer> loadCustomers() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Customer>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>();
        }
    }
}
