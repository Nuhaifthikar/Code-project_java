
package sunshineservice;

import java.util.List;


public class Report {
    String reportID;
    JobOrder jobOrder;
    String workDone;
    String sparePartsUsed;
    int timeSpent;
    String newCondition;

    public Report(String reportID, String workDone) {
        this.reportID = reportID;
        this.jobOrder = jobOrder;
        this.workDone = workDone;
        this.sparePartsUsed = sparePartsUsed;
        this.timeSpent = timeSpent;
        this.newCondition = newCondition;
    }

    public String getReportID() {
        return reportID;
    }

    public JobOrder getJobOrder() {
        return jobOrder;
    }

    public String getWorkDone() {
        return workDone;
    }

    public String getSparePartsUsed() {
        return sparePartsUsed;
    }

    public int getTimeSpent() {
        return timeSpent;
    }

    public String getNewCondition() {
        return newCondition;
    }

    public String getJobId() {
        return jobOrder != null ? jobOrder.getJobID() : "Unknown";
    }

    public String getSummary() {
        return workDone;
    }

    public String getReportDetails() {
        return "Report ID: " + reportID +
               ", Job ID: " + getJobId() +
               ", Work Done: " + workDone +
               ", Spare Parts Used: " + sparePartsUsed +
               ", Time Spent: " + timeSpent + " hours" +
               ", New Condition: " + newCondition;
    }
}


