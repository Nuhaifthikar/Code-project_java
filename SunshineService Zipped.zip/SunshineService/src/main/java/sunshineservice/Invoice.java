
package sunshineservice;


class Invoice {
    String invoiceID;
    Customer customer;
    JobOrder jobOrder;
    double totalCost;
    String date;

    public Invoice(String invoiceID, Customer customer, JobOrder jobOrder, double totalCost, String date) {
        this.invoiceID = invoiceID;
        this.customer = customer;
        this.jobOrder = jobOrder;
        this.totalCost = totalCost;
        this.date = date;
    }

    public void generateInvoice() {
        System.out.println("Invoice ID: " + invoiceID);
        System.out.println("Customer: " + customer.getName());
        System.out.println("Total Cost: Lkr" + totalCost);
        System.out.println("Date: " + date);
    }
}
