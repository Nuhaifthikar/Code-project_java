
package sunshineservice;


abstract class Employee {
    String employeeID;
    String name;
    String address;
    protected String idNumber;
    protected String qualification;
    protected String username;
    protected String password;

    public Employee(String employeeID, String name, String address, String idNumber,
                    String qualification, String username, String password) {
        this.employeeID = employeeID;
        this.name = name;
        this.address = address;
        this.idNumber = idNumber;
        this.qualification = qualification;
        this.username = username;
        this.password = password;
    }
}

