
package sunshineservice;

import java.util.List;
import java.util.UUID;


class Technician extends Employee {

    
    String specialization;

    public Technician(String employeeID, String name, String address, String idNumber, String qualification, String username,
            String password, String specialization) {
        super(employeeID, name, address, idNumber, qualification, username, password);
        this.specialization = specialization;
    }
    

    public void inspectVehicle() {
        System.out.println("Vehicle is inspected by Technician: " + name);
        
    }

    public void performRepair() {
        System.out.println("Repair is performed.");
    }

    public Report generateReport(JobOrder jobOrder, String workDone, List<SparePart> sparePartsUsed, String newCondition, int timeSpent) {
        return new Report(UUID.randomUUID().toString(), workDone);
    }

    String getEmployeeID() {
        return super.employeeID;
    }
    
    
}
