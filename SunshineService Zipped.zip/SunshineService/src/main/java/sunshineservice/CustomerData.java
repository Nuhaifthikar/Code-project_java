/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sunshineservice;

/**
 *
 * @author ASUS
 */
public class CustomerData {
    public static String name;
    public static String id;
    public static String phone;
    public static String vehicle;
    public static String issue;
    
        public CustomerData(String id, String name, String phone) {
        this.id = id;
        this.name = name;
        this.phone = phone;
    }

    // Getter methods
    public String getId() { return id; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
}

