
package sunshineservice;


class Vehicle {
    String vehicleID;
    String make;
    String model;
    int year;
    String issueDescription;
    String condition;

    public Vehicle(String vehicleID, String make, String model, int year, String issueDescription, String condition) {
        this.vehicleID = vehicleID;
        this.make = make;
        this.model = model;
        this.year = year;
        this.issueDescription = issueDescription;
        this.condition = condition;
    }

    public String getVehicleDetails() {
        return "Vehicle ID: " + vehicleID + ", " + make + " " + model + ","+issueDescription+", (" + year + ")";
    }

    public void updateCondition(String newCondition) {
        this.condition = newCondition;
    }

    public String getIssueDescription() {
        return issueDescription;
    }
}
