package sunshineservice;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class SunshineService {
    private static final String CUSTOMER_FILE = "customers.txt";
    private static final String JOBORDER_FILE = "joborders.txt";
    private static final String REPORT_FILE = "reports.txt";
    private static final List<Report> reports = new ArrayList<>();
    private static List<Technician> technicians = new ArrayList<>();


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Customer> customers = new ArrayList<>();
        List<JobOrder> jobOrders = new ArrayList<>();

        loadCustomers(customers);
        loadJobOrders(jobOrders, customers);

        while (true) {
            System.out.println("\n***Sunshine Service Pvt(Ltd) Menu ***");
            System.out.println("1. Register the Customer");
            System.out.println("2. Create the Job Order");
            System.out.println("3. View Customers");
            System.out.println("4. View Job Orders");
            System.out.println("5. Create Repair Report");
            System.out.println("6. View Reports");
            
            System.out.println("7. Exit");
            System.out.println("--------------------------------------");
            
            System.out.print("Choose an option: ");
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    Customer customer = new Customer();
                    customer.registerCustomer(scanner);
                    customers.add(customer);
                    saveCustomerToFile(customer);
                    break;
                case 2:
                    if (customers.isEmpty()) {
                        System.out.println("No customers registered!");
                        break;
                    }

                    System.out.print("Enter Customer ID for Job Order: ");
                    String custID = scanner.nextLine();
                    Customer found = null;
                    for (Customer c : customers) {
                        if (c.getCustomerID().equals(custID)) {
                            found = c;
                            break;
                        }
                    }
                    if (found == null) {
                        System.out.println("Customer not found!");
                        break;
                    }

                    System.out.print("Enter Vehicle ID: ");
                    String vid = scanner.nextLine();
                    System.out.print("Enter Make: ");
                    String make = scanner.nextLine();
                    System.out.print("Enter Model: ");
                    String model = scanner.nextLine();
                    System.out.print("Enter Year: ");
                    int year = Integer.parseInt(scanner.nextLine());
                    System.out.print("Describe the issue: ");
                    String issue = scanner.nextLine();
                    System.out.print("Condition: ");
                    String condition = scanner.nextLine();
                    System.out.print("Problematic parts: ");
                    String parts = scanner.nextLine();
                    System.out.print("Date of Handover: ");
                    String date = scanner.nextLine();

                    Vehicle vehicle = new Vehicle(vid, make, model, year, issue, condition);
                    JobOrder job = new JobOrder("JOB" + (jobOrders.size() + 1), found, vehicle, "T001", 
                            issue, parts, date, "S001");
                    jobOrders.add(job);
                    saveJobOrderToFile(job);
                    System.out.println("Job order created successfully!");
                    break;
                case 3:
                    for (Customer c : customers) {
                        System.out.println("Customer ID: " + c.getCustomerID() + " | Name: " + c.getName());
                    }
                    break;
                case 4:
                    for (JobOrder j : jobOrders) {
                        System.out.println("Job ID: " + j.getJobID() + " | Customer: " 
                                + j.getCustomer().getName() + " | Issue: " + j.getIssue());
                    }
                    break;
                case 5:
                    System.out.print("Enter Job ID to create report for: ");
                    String jobId = scanner.nextLine();
                    JobOrder targetJob = null;
                    for (JobOrder j : jobOrders) {
                        if (j.getJobID().equals(jobId)) {
                            targetJob = j;
                            break;
                        }
                    }
                    if (targetJob == null) {
                        System.out.println("Job ID not found.");
                        break;
                    }

                    System.out.print("Enter repair summary: ");
                    String summary = scanner.nextLine();

                    Report report = new Report(jobId, summary);
                    reports.add(report);
                    saveReportToFile(report);
                    System.out.println("Report created successfully!");
                    break;
                case 6:
                    if (reports.isEmpty()) {
                        System.out.println("No reports found.");
                    } else {
                        for (Report r : reports) {
                            System.out.println("Job ID: " + r.getJobId() + " | Summary: " + r.getSummary());
                        }
                    }
                    break;
                
                case 7:
                    System.out.println("Exiting Sunshine Service...");
                    return;
                    
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
    private static void saveCustomerToFile(Customer customer) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(CUSTOMER_FILE, true))) {
            pw.println(customer.getCustomerID() + "," + customer.getName());
        } catch (IOException e) {
            System.out.println("Error saving customer.");
        }
    }

    private static void saveJobOrderToFile(JobOrder job) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(JOBORDER_FILE, true))) {
            pw.println(job.getJobID() + "," + job.getCustomer().getCustomerID() + "," 
                    + job.getVehicle().getVehicleDetails() + "," + job.getIssue() + "," + job.getDateOfHandover());
        } catch (IOException e) {
            System.out.println("Error saving job order.");
        }
    }

    private static void saveReportToFile(Report report) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(REPORT_FILE, true))) {
            pw.println(report.getJobId() + "," + report.getSummary());
        } catch (IOException e) {
            System.out.println("Error saving report.");
        }
    }

    private static void loadCustomers(List<Customer> customers) {
        File file = new File(CUSTOMER_FILE);
        if (!file.exists()) return;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length >= 2) {
                    Customer customer = new Customer();
                    customer.registerCustomerFromFile(data[0], data[1]);
                    customers.add(customer);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading customers.");
        }
    }

    private static void loadJobOrders(List<JobOrder> jobOrders, List<Customer> customers) {
        File file = new File(JOBORDER_FILE);
        if (!file.exists()) return;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length >= 5) {
                    String jobID = data[0];
                    String customerID = data[1];
                    String issue = data[3];
                    String date = data[4];

                    Customer customer = null;
                    for (Customer c : customers) {
                        if (c.getCustomerID().equals(customerID)) {
                            customer = c;
                            break;
                        }
                    }

                    if (customer != null) {
                        Vehicle v = new Vehicle("Unknown", "Unknown", "Unknown", 0, issue, "Unknown");
                        JobOrder job = new JobOrder(jobID, customer, v, "T001", issue, "Unknown", date, "S001");
                        jobOrders.add(job);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading job orders.");
        }
    }
}
