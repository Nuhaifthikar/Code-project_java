
package sunshineservice;


class JobOrder {

    static void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    String jobID;
    Customer customer;
    Vehicle vehicle;
    String assignedTechnicianID;
    String issue;
    String parts;
    String dateOfHandover;
    String specialistID;

    public JobOrder(String jobID, Customer customer, Vehicle vehicle, String assignedTechnicianID, String issue, 
            String parts, String dateOfHandover, String specialistID) {
        this.jobID = jobID;
        this.customer = customer;
        this.vehicle = vehicle;
        this.assignedTechnicianID = assignedTechnicianID;
        this.issue = issue;
        this.parts = parts;
        this.dateOfHandover = dateOfHandover;
        this.specialistID = specialistID;
    }

    public String getJobID() {
        return jobID;
    }
    public Customer getCustomer() {
        return customer;
    }
    public String getIssue() {
        return issue;
    }
    public Vehicle getVehicle(){
        return vehicle;
    }

    public void updateJobOrder(String newIssue, String newParts) {
        this.issue = newIssue;
        this.parts = newParts;
    }
    

    public String setAssignedTechnician(Technician technician) {
        return assignedTechnicianID;
    }

    public String getDateOfHandover() {
        return dateOfHandover;
    }
}
