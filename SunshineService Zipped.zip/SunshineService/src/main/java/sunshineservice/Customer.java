
package sunshineservice;

import java.util.Scanner;

public class Customer {
    String customerID;
    String name;
    String contactNumber;
    String email;

    public void registerCustomer(Scanner scanner) {
        System.out.print("Enter Customer ID: ");
        this.customerID = scanner.nextLine();
        System.out.print("Enter Name: ");
        this.name = scanner.nextLine();
        System.out.print("Enter Contact Number: ");
        this.contactNumber = scanner.nextLine();
        System.out.print("Enter Email: ");
        this.email = scanner.nextLine();
    }

    public void updateCustomerDetails(Scanner scanner) {
        System.out.print("Update Name: ");
        this.name = scanner.nextLine();
        System.out.print("Update Contact Number: ");
        this.contactNumber = scanner.nextLine();
        System.out.print("Update Email: ");
        this.email = scanner.nextLine();
    }

    
    public String getCustomerID() {
        return customerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name=name;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber=contactNumber;
    }

    public void setEmail(String email) {
        this.email=email;
    }

    public void registerCustomerFromFile(String customerID, String name) {
        this.customerID=customerID;
        this.name=name;
    }

    String getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getPhone() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

    
