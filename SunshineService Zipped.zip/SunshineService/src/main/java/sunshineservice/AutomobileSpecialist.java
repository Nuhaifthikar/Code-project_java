
package sunshineservice;


class AutomobileSpecialist extends Employee {
    public AutomobileSpecialist(String employeeID, String name, String address, String idNumber, String qualification, String username, 
            String password) {
        super(employeeID, name, address, idNumber, qualification, username, password);
    }

    public void assignTechnician(JobOrder jobOrder, Technician technician) {
        jobOrder.setAssignedTechnician(technician);
        System.out.println(name + " assigned technician " + technician.name + " to job.");
    }

    public void sendToRepair(JobOrder jobOrder) {
        System.out.println(name + " sent vehicle to repair station.");
    }
    
}
