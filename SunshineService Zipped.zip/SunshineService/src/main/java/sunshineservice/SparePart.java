
package sunshineservice;


public class SparePart {
    String partID,name;
    double cost;
    int quantity;
    
    public SparePart(String partID, String name, double cost, int quantity) {
        this.partID = partID;
        this.name = name;
        this.cost = cost;
        this.quantity = quantity;
    }

    public void updateStock(int amountUsed) {
        this.quantity -= amountUsed;
    }

    public String getPartDetails() {
        return partID + ": " + name + " - $" + cost + " (Qty: " + quantity + ")";
    }
}
